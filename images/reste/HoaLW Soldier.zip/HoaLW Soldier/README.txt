Original by Estrellado, Vandolf
License: CC-BY 3.0
Attribution Instruction: "HoaLW Soldier", and include link to vestrel00.wix.com/hoalw

You can make any pose you want with the GIMP files.
All you need to do is rotate stuff =).